<?php

require_once 'config' . DIRECTORY_SEPARATOR . 'bdd.php';


if($_GET){

  if($_GET['action'] === 'getLike'){
    $req = $pdo->prepare('SELECT * FROM buttonLike WHERE id = 1');
    $req->execute();
    $data = $req->fetch();
    
    echo json_encode($data);
  }

  elseif($_GET['action'] === 'setLike'){
    $req = $pdo->prepare('SELECT * FROM buttonLike WHERE id = 1');
    $req->execute();
    $data = $req->fetch();

    $nombreUpdate = $data['nombre'] + 1;

    $req = $pdo->prepare('UPDATE buttonLike SET nombre = :nombre WHERE id = 1');
    $req->execute(['nombre' => $nombreUpdate]);

    echo json_encode($nombreUpdate);
  }

  elseif($_GET['action'] === 'resetLike'){
    $_POST = json_decode(file_get_contents('php://input'), true);

    $req = $pdo->prepare('UPDATE buttonLike SET nombre = :nombre WHERE id = 1');
    $req->execute(['nombre' => $_POST['nombre']]);

    echo json_encode($_POST['nombre']);

  }

}






