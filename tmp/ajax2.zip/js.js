window.addEventListener('load', () => {
  buttonInit();
})

var buttonLike = document.querySelector('.buttonLike')
var buttonReset = document.querySelector('.buttonReset')

async function buttonInit(){
  getLike()

  buttonLike.addEventListener('click', () => {
    setLike()
  })

  buttonReset.addEventListener('click', () => {
    resetLike({'nombre' : 0})
  })
}


  async function getLike(){
    let response = await fetch('http://localhost/ajax2/php/php.php?action=getLike')
    if(response.ok){
      let data = await response.json()
      buttonLikeAffichageUpdate(data.nombre)
    }
  }

  async function setLike(){
    let response = await fetch('http://localhost/ajax2/php/php.php?action=setLike')
    if(response.ok){
      let data = await response.json()
      buttonLikeAffichageUpdate(data)
    }
  }

  async function resetLike(data){
    let request = new Request('http://localhost/ajax2/php/php.php?action=resetLike', {
      method: 'POST',
      headers:{
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    })
    let response = await fetch(request)
    let responseData = await response.json()

    buttonLikeAffichageUpdate(responseData)
  }



function buttonLikeAffichageUpdate(nombre){
  let textAffichage
  if(nombre < 2){textAffichage = ' Like'}
  else{textAffichage = ' Likes'}

  buttonLike.innerHTML = nombre + textAffichage
}















// async function maFonctionRecursive(){

//   let response = await fetch('http://localhost/ajax2/php/php.php')
//   if(response.ok){
//     let data = await response.json()
//     buttonLike.innerHTML = data.nombre + ' Likes';
//     console.log(data)
//   }

//   setTimeout(() => {
//     maFonctionRecursive()
//   }, 2000)
// }

